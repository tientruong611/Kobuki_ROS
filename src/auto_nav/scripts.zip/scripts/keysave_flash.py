#!/usr/bin/env python3
import rospy
import yaml
import tf
import sys, select, termios, tty
from geometry_msgs.msg import Twist
from std_msgs.msg import String

# Khởi tạo node ROS
rospy.init_node('turtlebot_teleop_keysave')

# Tạo một đối tượng của tf.TransformListener để lắng nghe và theo dõi biến đổi tọa độ
listener = tf.TransformListener()

# Tên frame nguồn và frame đích
source_frame = "base_link"
target_frame = "map"

def get_location():
    try:
        (trans, rot) = listener.lookupTransform(target_frame, source_frame, rospy.Time(0))
        print(f"Transform from {source_frame} to {target_frame}")
        print(f"Translation: {trans}")
        print(f"Rotation: {rot}")
        return trans, rot
    except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
        rospy.logerr("Failed to lookup transform")
        return None, None

def save_location(waypoints, trans, rot):
    # Tự động tạo tên waypoint dựa trên số lượng waypoints đã có
    waypoint_name = f'waypoint{len(waypoints) + 1}'
    #stop_time = rospy.Time.now().to_sec()  # Thời gian hiện tại (giây)
    # Làm tròn giá trị tọa độ với 6 số sau dấu thập phân, và chuyển về kiểu float
    rounded_trans = [float(f"{coord:.4f}") for coord in trans]
    rounded_rot = [float(f"{coord:.4f}") for coord in rot]

    waypoints.append({
        'name': waypoint_name,
        'position': {'x': rounded_trans[0], 'y': rounded_trans[1], 'z': rounded_trans[2]},
        'orientation': {'w': rounded_rot[3], 'x': rounded_rot[0], 'y': rounded_rot[1], 'z': rounded_rot[2]},
        #'time': stop_time
    })

    # Tạo từ điển mới với khóa 'waypoints'
    yaml_data = {'waypoints': waypoints}

    with open('/home/vm/catkin_ws/src/auto_nav/scripts/waypoints.yaml', 'w') as file:
        yaml.dump(yaml_data, file, default_flow_style=False)  # Ghi từ điển mới

    print(f"Location saved as {waypoint_name}!")

def callback(data):
    if data.data == "save":
        trans, rot = get_location()
        if trans is not None and rot is not None:
            save_location(waypoints, trans, rot)

if __name__=="__main__":
    waypoints = []  # Danh sách lưu trữ waypoints
    rospy.Subscriber("/save_request", String, callback)  # Đăng ký subscriber cho topic "/save_request"
     
    rospy.spin()  # Chạy vòng lặp ROS
