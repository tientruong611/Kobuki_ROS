import rospy
from std_msgs.msg import String
import subprocess
import os

# Biến toàn cục để lưu trữ các subprocess
sub_processes = []

def real_navigation_multiple():
    global subprocess
    save_key = subprocess.Popen(['rosrun', 'auto_nav', 'keysave_flash.py'])
    navigation_ttb2 = subprocess.Popen(['roslaunch','auto_nav','navigation_ttb2.launch'])
    sub_processes.extend([save_key,navigation_ttb2])     
def callback(data):
    global sub_processes

    rospy.loginfo("Nhận được thông điệp từ topic /subscriber: %s", data.data)
    if data.data == "1":
        rospy.loginfo("Chạy subprocess data 1...")
        if not sub_processes:
            #------chay thuc te---------------------
            process = subprocess.Popen('roslaunch auto_nav slam_hector_savemap.launch', shell=True)            
        else:
            rospy.loginfo("Có subprocess đang chạy, không thể khởi chạy lại subprocess có data là 1")
    elif data.data == "2":
        rospy.loginfo("Chạy subprocess data 2...")
        #------chay thuc te-------
        real_navigation_multiple()
    elif data.data == "3":
        rospy.loginfo("Chạy subprocess data 3...")
        #--------------chay thuc te------------
        process = subprocess.Popen('rosrun map_server map_saver -f /home/vm/catkin_ws/src/turtlebot_apps/turtlebot_navigation/maps/map', shell=True)       

        sub_processes.append(process)
    elif data.data == "4":
        process = subprocess.Popen('rosrun auto_nav multiple_waypoints_read_tien.py', shell=True)
        sub_processes.append(process)
    elif data.data == "10":
        for proc in sub_processes:
            rospy.loginfo("Chấm dứt subprocess...")
            proc.terminate()
            proc.wait()
        sub_processes.clear()

def listener():
    rospy.init_node('subscriber_node', anonymous=True)
    rospy.Subscriber("/subscriber", String, callback)
    rospy.spin()

if __name__ == '__main__':
    listener()
