import tkinter as tk

def button_click():
    print("Button clicked!")

# Tạo cửa sổ giao diện
root = tk.Tk()
root.title("Giao diện đơn giản")

# Tạo một nút nhấn
button = tk.Button(root, text="Nhấn vào đây", command=button_click)
button.pack(pady=20)  # Đặt nút vào cửa sổ và tạo khoảng cách dưới nút

# Bắt đầu vòng lặp chạy của cửa sổ
root.mainloop()

